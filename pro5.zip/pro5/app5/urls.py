from django.urls import path
from .import views
urlpatterns=[
    path('usave',views.user_save)
]