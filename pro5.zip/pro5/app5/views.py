from django.shortcuts import render
from app5.models import Users
def user_save(request):
    a=request.GET['username']
    b=request.GET['phone']
    c=request.GET['password']
    data=Users(username=a,phone=b,password=c)
    data.save()
    return render(request, 'loginn.html')
# Create your views here.
